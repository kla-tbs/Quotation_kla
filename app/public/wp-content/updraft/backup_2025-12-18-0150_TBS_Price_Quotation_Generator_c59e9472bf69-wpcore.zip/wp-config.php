<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '1Zm_V5[25Ix) RfL]#w5U+W~)Wcy@]T )/Fcpgwh0h[J[GALFrfUctnsnB5l.sc:' );
define( 'SECURE_AUTH_KEY',   '`.~uso}`Qg!Co}dq7w8cF`Gyrq62g_;[$E?j#A/n1vp9VHP`LtJA7d}0xt4YpXny' );
define( 'LOGGED_IN_KEY',     't--&[~~r@.X2:NsF^woEo,:9.I5Z}l:.}7:X7#Yt<KNq_YtcjeobqrHSj82S@gHn' );
define( 'NONCE_KEY',         'S5k_uaa-w6+_n:M 0NhmrN8#QO)~EDUgqAF_wAs]6vc%s2wA<}!)T)vh0{rVOF79' );
define( 'AUTH_SALT',         '3-2r1dbB3R3dAn!..W5/RiK_dNR{9T3++Ytr{[=BbdG`R#?(HbLZQYSMTQ`(-]$2' );
define( 'SECURE_AUTH_SALT',  '3[k~#eLxg-%7HG*-ji<KFA9ad(*azc|+qB|]O6$3`^DlvFU82P[3>:L,)*nmW(sa' );
define( 'LOGGED_IN_SALT',    '*awgQv|m-pETL/~MZcPZDFGiUA!abF?xfC*4/p/Q.*-+x_6C$!Y>M2;+%[IxqX>T' );
define( 'NONCE_SALT',        '%ar!ibz@R+.@3JM9I<a:IHwsRlZ*IUv*tHv-aO}bX81_JoGJfgPJScH0A}>La-@Y' );
define( 'WP_CACHE_KEY_SALT', '5C4^S-Drd:y]?b&GczzK}G~p@L%9^%SyM:%67&RuDMQ1yRyY{ [Fgz8f*/KTzxGp' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */

if ( ! defined( 'WP_DEBUG' ) ) { define( 'WP_DEBUG', false ); }

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
